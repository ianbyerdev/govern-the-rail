"""Fixed public API smoke; cookies stay in memory and are never exported."""
from pathlib import Path
import datetime
import json
import subprocess
import sys
import time
import httpx
from saac.coverage_verifier import verify_bundle

OUT = Path(__file__).resolve().parent
container = json.loads((OUT/'container.json').read_text())
BASE = 'http://' + container['binding']
headers = {'X-SAAC-Demo': '1', 'Origin': BASE}
checks, requests, commands = [], [], []


def check(name, condition, detail=None):
    checks.append({'check': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(name)


def request(client, method, path, *, body=None, expected=200, **kwargs):
    response = client.request(method, path, json=body, **kwargs)
    requests.append({'method': method, 'path': path, 'body': body,
                     'status_code': response.status_code, 'expected_status': expected})
    check(f'{method} {path}: HTTP {expected}', response.status_code == expected,
          {'observed': response.status_code})
    return response


def has_secret_field(value):
    if isinstance(value, dict):
        return any(key.lower() in ('operator_token', 'actor_token', 'access_token', 'authorization',
                                  'private_key', 'secret_key') or has_secret_field(child)
                   for key, child in value.items())
    if isinstance(value, list):
        return any(has_secret_field(child) for child in value)
    return False


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
error = None
try:
    with httpx.Client(base_url=BASE, headers=headers, timeout=60) as a, \
         httpx.Client(base_url=BASE, headers=headers, timeout=60) as b:
        homepage = request(a, 'GET', '/')
        check('Frontend HTML served by container', '<div id="root">' in homepage.text)
        for client in (a, b):
            session = request(client, 'POST', '/api/demo/session').json()
            check('Public session exposes no credential fields', not has_secret_field(session))
        catalog = request(a, 'GET', '/api/demo/coverage').json()
        check('Public C8 explicitly unsupported', not next(c for c in catalog['cases'] if c['id'] == 'C8')['supported'])
        request(a, 'POST', '/api/demo/coverage/C8/run', body={'request_id': 'container-c8-unsupported'}, expected=403)
        request(a, 'GET', '/api/operator/coverage', expected=401)
        request(a, 'POST', '/api/demo/coverage/C9/run', body={'request_id': 'cross-origin'},
                headers={'Origin': 'http://different-origin.invalid'}, expected=403)
        identifiers = {}
        for case in ('C9', 'C10'):
            view = request(a, 'POST', f'/api/demo/coverage/{case}/run',
                           body={'request_id': f'container-{case.lower()}'}).json()
            identifiers[case] = view['id']
            check(f'{case} actual backend run observed', view['status'] == 'observed' and view['verification']['valid'])
            check(f'{case} unsafe control detected independently', view['verification']['negative_control_detected'] and
                  not view['verification']['conformance']['unsafe']['valid'])
            bundle = request(a, 'GET', f"/api/demo/coverage/runs/{view['id']}/export").json()
            check(f'{case} export exposes no credential fields', not has_secret_field(bundle))
            path = OUT/f'{case}-public-observed.json'
            path.write_text(json.dumps(bundle, indent=2)+'\n')
            host_result = verify_bundle(bundle)
            (OUT/f'{case}-host-verifier.json').write_text(json.dumps(host_result, indent=2)+'\n')
            check(f'{case} host offline verifier accepts observed export', host_result['valid'])
            cmd = ['docker', 'exec', '-i', container['container_id'], 'python', '-c',
                   'import json,sys; from saac.coverage_verifier import verify_bundle; r=verify_bundle(json.load(sys.stdin)); print(json.dumps(r)); sys.exit(0 if r["valid"] else 1)']
            result = subprocess.run(cmd, input=path.read_text(), capture_output=True, text=True, timeout=60)
            commands.append({'command': cmd, 'stdin_file': str(path), 'exit_code': result.returncode})
            check(f'{case} in-container offline verifier exits zero', result.returncode == 0)
            parsed = json.loads(result.stdout)
            check(f'{case} in-container offline verifier detects negative control', parsed['valid'] and parsed['negative_control_detected'])
            (OUT/f'{case}-container-verifier.json').write_text(json.dumps(parsed, indent=2)+'\n')
        for suffix in ('', '/export'):
            request(b, 'GET', '/api/demo/coverage/runs/'+identifiers['C9']+suffix, expected=409)
        isolated = request(b, 'POST', '/api/demo/coverage/C9/run', body={'request_id': 'container-c9'}).json()
        check('Same request id in second session creates isolated run', isolated['id'] != identifiers['C9'])
        # C9 costs two books and C10 six; four ordinary books exhaust the shared twelve-book quota.
        for _ in range(4):
            request(a, 'POST', '/api/demo/workbench/books', body={'profile': 'trading'})
        request(a, 'POST', '/api/demo/workbench/books', body={'profile': 'trading'}, expected=429)
        request(a, 'POST', '/api/demo/coverage/C9/run', body={'request_id': 'quota-c9'}, expected=429)
        request(a, 'POST', '/api/demo/coverage/C10/run', body={'request_id': 'quota-c10'}, expected=429)
        replay = request(a, 'POST', '/api/demo/coverage/C9/run', body={'request_id': 'container-c9'}).json()
        check('Durable retry at quota returns existing run', replay['id'] == identifiers['C9'])
        catalog = request(a, 'GET', '/api/demo/coverage').json()
        check('Quota failures and retry did not create extra coverage runs', len(catalog['runs']) == 2)
        check('Source packaged without Git metadata is labeled unavailable',
              replay['provenance']['source_commit'] is None and replay['provenance']['source_dirty'] is None)
except Exception as exc:
    error = {'type': type(exc).__name__, 'message': str(exc)}
finally:
    result = {'scope': 'local-container/public-profile tested; remote hosted provider NOT tested',
              'started_at': started, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'checks_passed': sum(c['passed'] for c in checks), 'checks_total': len(checks),
              'request_count': len(requests), 'checks': checks, 'requests': requests,
              'commands': commands, 'error': error,
              'credentials_exported': False, 'operator_token_read_or_used': False,
              'limitations': ['The image omits Git metadata; build provenance maps the image ID to the clean source commit.',
                              'Remote hosted provider deployment was not tested.',
                              'C8 public execution is intentionally unsupported.']}
    (OUT/'public-api-smoke-result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('checks_passed', 'checks_total', 'request_count', 'error', 'scope')}))
    raise SystemExit(1 if error else 0)
