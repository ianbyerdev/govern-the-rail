# Observed C8–C10 run

Executed source: `f7d27db01702f61f1dca0fd12f59900ca030f8da`.
Clean source checkout.

All domain numbers in case JSON are integer cents; display scale is 100.
Unsafe branches fail ordinary conformance. Experiment verification passes only when the specified breach is detected.

| Case | Evidence valid | Intended breach detected |
|---|---|---|
| C8 | True | True |
| C9 | True | True |
| C10 | True | True |

Backend counts: `{'passed': 359, 'failed': 0, 'skipped': 0}`.
Browser counts: `{'expected': 39, 'unexpected': 0, 'flaky': 0, 'skipped': 0}`.
See test-results.json for commands, exit codes and explicit skipped checks.
No private keys, credentials, live databases or claimed CI URL are included.
The full fixture history and public keys are locally rooted and not externally anchored.
