# Observed C8–C10 run

Executed source: `4f5e3dc3e4fde9805ada11ea72369b9cd6f5b8bb`.
Clean source checkout.

All domain numbers in case JSON are integer cents; display scale is 100.
Unsafe branches fail ordinary conformance. Experiment verification passes only when the specified breach is detected.

| Case | Evidence valid | Intended breach detected |
|---|---|---|
| C8 | True | True |
| C9 | True | True |
| C10 | True | True |

Backend counts: `{'passed': 359, 'failed': 0, 'skipped': 0}`.
Browser counts: `{'expected': 39, 'unexpected': 1, 'flaky': 0, 'skipped': 0}`.
See test-results.json for commands, exit codes and explicit skipped checks.
No private keys, credentials, live databases or claimed CI URL are included.
The full fixture history and public keys are locally rooted and not externally anchored.
