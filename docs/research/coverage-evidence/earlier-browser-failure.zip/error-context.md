# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uncertain.spec.ts >> public uncertain experiments remain isolated and fit a phone
- Location: tests/uncertain.spec.ts:283:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Pay one exact beneficiary' })
Expected: visible
Timeout: 45000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Pay one exact beneficiary' }) with timeout 45000ms
  - waiting for getByRole('heading', { name: 'Pay one exact beneficiary' })

```

```yaml
- main:
  - img
  - text: Agentic RISC · Independent institutional controls
  - heading "Govern The Rail Lab" [level=1]
  - paragraph: The actor proposes. The RISC Runtime authorizes. The RISC Gateway enforces.
  - paragraph: Try a payment, challenge the boundary, or launch 100 agents against one shared limit. Follow every capability and receipt.
  - alert: Please wait before trying again.
  - button "Start demo":
    - text: Start demo
    - img
  - paragraph: No account or credential needed.
  - img
  - strong: Your own workspace
  - text: Experiment without changing anyone else’s demo.
  - img
  - strong: One shared authority
  - text: Every agent in your experiment uses the same book.
  - img
  - strong: 60-minute session
  - text: Export evidence you want to keep. Temporary data is cleared on expiry or a host reset.
  - group: Administrator access
```

# Test source

```ts
  1   | import {
  2   |   test,
  3   |   expect as baseExpect,
  4   |   type Locator,
  5   |   type Page,
  6   | } from "@playwright/test";
  7   | import fs from "node:fs";
  8   | import path from "node:path";
  9   | 
  10  | const expect = baseExpect.configure({ timeout: 45000 });
  11  | test.setTimeout(120000);
  12  | 
  13  | async function openExperiment(page: Page, visitor = false) {
  14  |   await page.goto(
  15  |     visitor ? "/" : "/#token=" + fs.readFileSync(".test-token", "utf8"),
  16  |   );
  17  |   if (visitor)
  18  |     await page.getByRole("button", { name: "Start demo", exact: true }).click();
  19  |   await expect(
  20  |     page.getByRole("heading", { name: "Pay one exact beneficiary" }),
> 21  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  22  |   await page
  23  |     .getByRole("button", { name: "Missing receipt experiment", exact: true })
  24  |     .click();
  25  |   await expect(
  26  |     page.getByRole("heading", {
  27  |       name: "A missing receipt does not create capacity",
  28  |     }),
  29  |   ).toBeVisible();
  30  |   await expect(page.locator(".uncertain-feedback")).not.toHaveText(
  31  |     "Loading experiment",
  32  |   );
  33  | }
  34  | 
  35  | function panels(page: Page) {
  36  |   return {
  37  |     evidence: page.getByRole("article", {
  38  |       name: "Evidence-based policy",
  39  |       exact: true,
  40  |     }),
  41  |     timeout: page.getByRole("article", {
  42  |       name: "Release on timeout policy",
  43  |       exact: true,
  44  |     }),
  45  |   };
  46  | }
  47  | 
  48  | async function expectBook(
  49  |   panel: Locator,
  50  |   consumed: number,
  51  |   reserved: number,
  52  |   available: number,
  53  | ) {
  54  |   for (const [metric, value] of Object.entries({
  55  |     limit: 10,
  56  |     consumed,
  57  |     reserved,
  58  |     available,
  59  |   })) {
  60  |     await expect(panel.locator(`[data-metric="${metric}"] dd`)).toHaveText(
  61  |       String(value),
  62  |     );
  63  |   }
  64  | }
  65  | 
  66  | async function step(page: Page, label: string) {
  67  |   await page
  68  |     .getByRole("button", { name: "Step: " + label, exact: true })
  69  |     .click();
  70  |   await expect(
  71  |     page
  72  |       .getByRole("region", { name: "Current experiment frame" })
  73  |       .getByRole("heading", { name: label, exact: true }),
  74  |   ).toBeVisible();
  75  | }
  76  | 
  77  | function evidenceScreenshot(name: string) {
  78  |   const folder = process.env.SAAC_EVIDENCE_DIR;
  79  |   if (folder) fs.mkdirSync(folder, { recursive: true });
  80  |   return folder ? path.join(folder, name) : test.info().outputPath(name);
  81  | }
  82  | 
  83  | test("uncertain execution exposes matched admission, deadline divergence and evidence recovery", async ({
  84  |   page,
  85  | }) => {
  86  |   await openExperiment(page);
  87  |   // Operator experiments survive test cases; resetting creates an isolated book pair.
  88  |   const reset = page.getByRole("button", {
  89  |     name: "Reset to new experiment",
  90  |     exact: true,
  91  |   });
  92  |   if (await reset.isEnabled()) await reset.click();
  93  |   await step(page, "Initial admission");
  94  |   const { evidence, timeout } = panels(page);
  95  |   for (const panel of [evidence, timeout]) {
  96  |     await expectBook(panel, 0, 10, 0);
  97  |     await expect(
  98  |       panel.locator(".uncertain-admissions > div").first(),
  99  |     ).toContainText("100 submitted");
  100 |     await expect(
  101 |       panel.locator(".uncertain-admissions > div").first(),
  102 |     ).toContainText("10 admitted · 90 denied");
  103 |     await expect(panel).toContainText("10 valid unredeemed promises");
  104 |     await expect(panel.locator(".uncertain-total")).toContainText("10 units");
  105 |   }
  106 |   await step(page, "Working orders & hidden fills");
  107 |   for (const panel of [evidence, timeout]) {
  108 |     await expectBook(panel, 0, 10, 0);
  109 |     await expect(panel.locator("[data-metric=obligation]")).toHaveText(
  110 |       "10 units",
  111 |     );
  112 |     await expect(panel).toContainText("4 executed + 6 live order commitments");
  113 |   }
  114 |   await step(page, "Deadline");
  115 |   await expectBook(evidence, 0, 10, 0);
  116 |   await expectBook(timeout, 0, 0, 10);
  117 |   await evidence.getByText(/Exception queue ·/).click();
  118 |   await expect(evidence.locator("ul.uncertain-exceptions li")).toHaveCount(10);
  119 |   await expect(
  120 |     evidence.locator("ul.uncertain-exceptions li").first(),
  121 |   ).toContainText("Next action:");
```